import typer

app = typer.Typer()


@app.callback()
def main() -> None:
    """JIDO CLI."""
    return None


@app.command()
def scan() -> None:
    print("scan")
